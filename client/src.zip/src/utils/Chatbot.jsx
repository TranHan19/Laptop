function Chatbot() {
    return <div></div>;
}

export default Chatbot;
